# GoIT_Home_task_7
Home task 7 solution
